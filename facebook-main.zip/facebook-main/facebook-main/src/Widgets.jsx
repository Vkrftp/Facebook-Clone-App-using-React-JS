import React from 'react'
import "./Css_components/Widgets.css"

function Widgets() {
    return (
        <div className="widgets">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fawesomemobdesigns&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" frameborder="0" width="300" height="100%" style={{border:"none", overflow:"hidden", position:"relative", left:
        "-150px"}} scrolling="no" allowTransparency="true" allow="encrypted-media"></iframe>
           
        </div>
    )
}

export default Widgets
